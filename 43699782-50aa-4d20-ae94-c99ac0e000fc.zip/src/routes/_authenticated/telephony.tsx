import { createFileRoute } from "@tanstack/react-router";
import { queryOptions, useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "@/lib/notify";
import { Phone, Radio, Route as RouteIcon, Trash2 } from "lucide-react";
import { GlassCard, PageHeader, SystemLabel } from "@/components/apple";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { useWorkspace } from "@/lib/workspace";
import { addPhoneNumber } from "@/lib/platform.functions";

const sel = "rounded-md border border-input bg-background px-3 py-2 text-sm";

const telephonyQuery = (workspaceId: string) => queryOptions({
  queryKey: ["telephony", workspaceId],
  queryFn: async () => {
    const [{ data: numbers }, { data: agents }, { data: environments }, { data: deps }] = await Promise.all([
      supabase.from("phone_numbers").select("id, e164, carrier, agent_id, environment_id, status, sip_trunk_ref, dispatch_rule_ref").eq("workspace_id", workspaceId).order("created_at"),
      supabase.from("agents").select("id, name").eq("workspace_id", workspaceId).neq("status", "archived"),
      supabase.from("environments").select("id, name, kind").eq("workspace_id", workspaceId),
      supabase.from("deployments").select("agent_id, environment_id, agent_version").eq("workspace_id", workspaceId).eq("status", "active"),
    ]);
    return { numbers: numbers ?? [], agents: agents ?? [], environments: environments ?? [], deps: deps ?? [] };
  },
});

export const Route = createFileRoute("/_authenticated/telephony")({
  head: () => ({ meta: [
    { title: "Telephony and channels: aviroh" },
    { name: "description", content: "Add phone numbers, route them to agents and environments, and check channel readiness." },
    { property: "og:title", content: "Telephony and channels: aviroh" },
    { property: "og:description", content: "Add phone numbers, route them to agents and environments, and check channel readiness." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: Telephony,
});

function Telephony() {
  const workspace = useWorkspace();
  const qc = useQueryClient();
  const { data } = useSuspenseQuery(telephonyQuery(workspace.id));
  const addNumber = useServerFn(addPhoneNumber);
  const [num, setNum] = useState({ e164: "", carrier: "twilio" as "twilio" | "telnyx" | "other", agentId: "", environmentId: "" });
  const refresh = () => qc.invalidateQueries({ queryKey: ["telephony"] });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    try {
      const r = await addNumber({ data: { workspaceId: workspace.id, ...num } });
      toast.success(r.provisioned ? "Number connected" : "Number saved. Routing activates once the voice service is connected");
      setNum({ ...num, e164: "" }); refresh();
    } catch (err) { toast.error(err instanceof Error ? err.message : "Could not add number"); }
  }
  async function reroute(id: string, patch: { agent_id?: string; environment_id?: string }) {
    const { error } = await supabase.from("phone_numbers").update(patch).eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Routing updated"); refresh(); }
  }
  async function release(id: string, e164: string) {
    if (!confirm(`Remove ${e164} from aviroh? Calls to it will stop reaching your agents. Release it at your carrier separately.`)) return;
    const { error } = await supabase.from("phone_numbers").delete().eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Number removed"); refresh(); }
  }

  return <>
    <PageHeader eyebrow="Deploy" title="Telephony and channels" subtitle="Phone numbers and which agent answers each one." />
    <div className="mb-4 grid gap-3 sm:grid-cols-3">
      <GlassCard><Phone className="h-5 w-5 text-primary" /><p className="mt-4 font-mono text-2xl font-semibold">{data.numbers.length}</p><p className="text-sm text-muted-foreground">Phone numbers</p></GlassCard>
      <GlassCard><Radio className="h-5 w-5 text-realtime" /><p className="mt-4 font-mono text-2xl font-semibold">{data.numbers.filter((n) => n.status === "active").length}</p><p className="text-sm text-muted-foreground">Active routes</p></GlassCard>
      <GlassCard><RouteIcon className="h-5 w-5 text-warning" /><p className="mt-4 font-mono text-2xl font-semibold">{data.numbers.filter((n) => n.dispatch_rule_ref).length}</p><p className="text-sm text-muted-foreground">Dispatch rules</p></GlassCard>
    </div>
    <GlassCard className="mb-4 space-y-3">
      <h2 className="font-semibold">Add a number</h2>
      <p className="text-xs text-muted-foreground">Bring a number you own at Twilio, Telnyx, or another SIP carrier, then point its SIP trunk at the voice service.</p>
      <form onSubmit={submit} className="grid gap-2 md:grid-cols-5">
        <Input required placeholder="+15551234567" aria-label="Phone number" className="font-mono" value={num.e164} onChange={(e) => setNum({ ...num, e164: e.target.value.trim() })} />
        <select className={sel} aria-label="Carrier" value={num.carrier} onChange={(e) => setNum({ ...num, carrier: e.target.value as typeof num.carrier })}><option value="twilio">Twilio</option><option value="telnyx">Telnyx</option><option value="other">Other SIP</option></select>
        <select required className={sel} aria-label="Agent" value={num.agentId} onChange={(e) => setNum({ ...num, agentId: e.target.value })}><option value="">Agent</option>{data.agents.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</select>
        <select required className={sel} aria-label="Environment" value={num.environmentId} onChange={(e) => setNum({ ...num, environmentId: e.target.value })}><option value="">Environment</option>{data.environments.map((env) => <option key={env.id} value={env.id}>{env.name}</option>)}</select>
        <Button type="submit" className="rounded-full">Add number</Button>
      </form>
    </GlassCard>
    <GlassCard className="overflow-hidden p-0">
      <div className="border-b border-border p-5"><h2 className="font-semibold">Voice routes</h2><p className="mt-1 text-sm text-muted-foreground">Change the agent or environment a number reaches at any time.</p></div>
      {data.numbers.length === 0 ? <p className="p-5 text-sm text-muted-foreground">No phone numbers yet. Add one to start taking calls.</p> : <div className="divide-y divide-border">
        {data.numbers.map((n) => {
          const dep = data.deps.find((d) => d.agent_id === n.agent_id && d.environment_id === n.environment_id);
          return <div key={n.id} className="grid gap-3 p-5 text-sm md:grid-cols-[1.1fr_0.6fr_1fr_1fr_1fr_auto] md:items-center">
            <span className="font-mono font-medium">{n.e164}</span>
            <span className="text-muted-foreground">{n.carrier}</span>
            <select className={`${sel} py-1`} aria-label={`Agent for ${n.e164}`} value={n.agent_id ?? ""} onChange={(e) => reroute(n.id, { agent_id: e.target.value })}>{data.agents.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</select>
            <select className={`${sel} py-1`} aria-label={`Environment for ${n.e164}`} value={n.environment_id ?? ""} onChange={(e) => reroute(n.id, { environment_id: e.target.value })}>{data.environments.map((env) => <option key={env.id} value={env.id}>{env.name}</option>)}</select>
            <span className="text-xs">{dep ? <SystemLabel tone="live">Serves v{dep.agent_version}</SystemLabel> : <SystemLabel tone="warn">No active deployment</SystemLabel>}</span>
            <div className="flex items-center gap-2"><SystemLabel tone={n.status === "active" ? "ok" : "warn"}>{n.status === "active" ? "Connected" : "Not connected"}</SystemLabel><button aria-label={`Remove ${n.e164}`} className="text-muted-foreground hover:text-destructive" onClick={() => release(n.id, n.e164)}><Trash2 className="h-4 w-4" /></button></div>
          </div>;
        })}
      </div>}
    </GlassCard>
  </>;
}
