import { createFileRoute, redirect, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "@/lib/notify";
import { supabase } from "@/integrations/supabase/client";
import { AvirohMark } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/onboarding")({
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) throw redirect({ to: "/auth" });
  },
  head: () => ({
    meta: [
      { title: "Set up your organization: aviroh" },
      { name: "description", content: "Create your organization and first workspace on aviroh." },
      { property: "og:title", content: "Set up your organization: aviroh" },
      { property: "og:description", content: "Create your organization and first workspace on aviroh." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Onboarding,
});

function Onboarding() {
  const [org, setOrg] = useState("");
  const [ws, setWs] = useState("Main");
  const [busy, setBusy] = useState(false);
  const qc = useQueryClient();
  const navigate = useNavigate();
  async function create(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.rpc("create_organization", { _org_name: org.trim(), _workspace_name: ws.trim() });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    await Promise.all([
      qc.invalidateQueries({ queryKey: ["workspace"] }),
      qc.invalidateQueries({ queryKey: ["workspaces"] }),
    ]);
    navigate({ to: "/overview" });
  }
  return (
    <div className="grid min-h-screen place-items-center px-5">
      <form onSubmit={create} className="w-full max-w-md animate-rise space-y-4 rounded-lg border border-border bg-card p-8 ">
        <AvirohMark className="h-11 w-11" />
        <h1 className="text-2xl font-semibold tracking-tight">Set up your organization</h1>
        <p className="text-sm text-muted-foreground">Create the organization that owns your teams, workspaces, agents, and environments.</p>
        <label className="block text-sm">
          Organization name
          <Input className="mt-1" required maxLength={120} value={org} onChange={(e) => setOrg(e.target.value)} placeholder="Northstar Group" />
        </label>
        <label className="block text-sm">
          First workspace
          <Input className="mt-1" required maxLength={120} value={ws} onChange={(e) => setWs(e.target.value)} />
        </label>
        <Button type="submit" disabled={busy} className="w-full rounded-full">
          {busy ? "Creating" : "Create and continue"}
        </Button>
      </form>
    </div>
  );
}
