import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { runtimeHandler } from "@/lib/runtime/session.server";

// Voice worker reports a finished (or started) eval run. HMAC-signed like all runtime routes.
const Body = z.object({
  runId: z.string().uuid(),
  status: z.enum(["running", "completed", "failed"]),
  passed: z.number().int().min(0).optional(),
  total: z.number().int().min(0).optional(),
  score: z.number().int().min(0).max(100).optional(),
});

export const Route = createFileRoute("/api/public/runtime/eval-result")({
  server: {
    handlers: {
      POST: ({ request }) =>
        runtimeHandler(request, async (raw) => {
          const b = Body.parse(raw);
          const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
          const patch: Record<string, unknown> = { status: b.status };
          if (b.passed != null) patch["passed"] = b.passed;
          if (b.total != null) patch["total"] = b.total;
          if (b.score != null) patch["score"] = b.score;
          if (b.status !== "running") patch["finished_at"] = new Date().toISOString();
          const { error } = await supabaseAdmin.from("eval_runs").update(patch as never).eq("id", b.runId);
          if (error) throw new Error(error.message);
          return { ok: true };
        }),
    },
  },
});
