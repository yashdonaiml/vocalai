import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "@/lib/notify";
import { Mic, PhoneOff } from "lucide-react";
import type { Room } from "livekit-client";
import { GlassCard, SystemLabel } from "@/components/apple";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MODELS, REALTIME_VOICES, providerLabel, type Capability } from "@/lib/providers/catalog";
import { DEFAULT_COMPOSABLE, DEFAULT_RUNTIME, type ModelRef, type RuntimeConfig } from "@/lib/agent-config";
import { startTestSession } from "@/lib/platform.functions";

const sel = "w-full rounded-md border border-input bg-background px-3 py-2 text-sm";

function Label({ children }: { children: React.ReactNode }) {
  return <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{children}</span>;
}

function ModelSelect({ cap, value, onChange }: { cap: Capability; value: ModelRef; onChange: (v: ModelRef) => void }) {
  return (
    <select className={sel} value={`${value.provider}:${value.model}`}
      onChange={(e) => { const [provider, model] = e.target.value.split(":"); onChange({ provider: provider as ModelRef["provider"], model: model ?? "" }); }}>
      {MODELS[cap].map((m) => (
        <option key={`${m.provider}:${m.id}`} value={`${m.provider}:${m.id}`}>{providerLabel(m.provider)} · {m.label}</option>
      ))}
    </select>
  );
}

export function RuntimeEditor({ value, onChange }: { value: RuntimeConfig; onChange: (v: RuntimeConfig) => void }) {
  return (
    <div className="space-y-4">
      <label className="block">
        <Label>Execution mode</Label>
        <select className={`${sel} mt-1.5`} value={value.mode}
          onChange={(e) => onChange(e.target.value === "native" ? DEFAULT_RUNTIME : DEFAULT_COMPOSABLE)}>
          <option value="native">Native realtime (speech-to-speech)</option>
          <option value="composable">Composable: STT → LLM → TTS</option>
        </select>
      </label>
      {value.mode === "native" ? (
        <>
          <label className="block"><Label>Realtime model</Label><div className="mt-1.5">
            <ModelSelect cap="realtime" value={value.realtime}
              onChange={(realtime) => onChange({ ...value, realtime, voice: REALTIME_VOICES[realtime.provider]?.[0] ?? "" })} />
          </div></label>
          <label className="block"><Label>Voice</Label>
            <select className={`${sel} mt-1.5`} value={value.voice} onChange={(e) => onChange({ ...value, voice: e.target.value })}>
              {(REALTIME_VOICES[value.realtime.provider] ?? []).map((v) => <option key={v}>{v}</option>)}
            </select>
          </label>
        </>
      ) : (
        <>
          <label className="block"><Label>Speech-to-text</Label><div className="mt-1.5"><ModelSelect cap="stt" value={value.stt} onChange={(stt) => onChange({ ...value, stt })} /></div></label>
          <label className="block"><Label>Language model</Label><div className="mt-1.5"><ModelSelect cap="llm" value={value.llm} onChange={(llm) => onChange({ ...value, llm })} /></div></label>
          <label className="block"><Label>Text-to-speech</Label><div className="mt-1.5"><ModelSelect cap="tts" value={value.tts} onChange={(t) => onChange({ ...value, tts: { ...t, voice: value.tts.voice } })} /></div></label>
          <label className="block"><Label>Voice ID</Label>
            <Input className="mt-1.5 font-mono" placeholder="Provider voice ID" value={value.tts.voice} onChange={(e) => onChange({ ...value, tts: { ...value.tts, voice: e.target.value } })} />
          </label>
        </>
      )}
    </div>
  );
}

type Status = "idle" | "connecting" | "live" | "ending";

export function TestCall({ agentId }: { agentId: string }) {
  const start = useServerFn(startTestSession);
  const [status, setStatus] = useState<Status>("idle");
  const [captions, setCaptions] = useState<{ id: string; role: string; text: string }[]>([]);
  const roomRef = useRef<Room | null>(null);
  const audioBox = useRef<HTMLDivElement>(null);

  useEffect(() => () => { void roomRef.current?.disconnect(); }, []);

  async function begin() {
    setStatus("connecting");
    setCaptions([]);
    try {
      const join = await start({ data: { agentId } });
      const { Room, RoomEvent, Track } = await import("livekit-client");
      const room = new Room({ adaptiveStream: true, dynacast: true });
      roomRef.current = room;
      room.on(RoomEvent.TrackSubscribed, (track) => {
        if (track.kind === Track.Kind.Audio) audioBox.current?.appendChild(track.attach());
      });
      room.on(RoomEvent.TranscriptionReceived, (segments, participant) => {
        const role = participant?.identity === room.localParticipant.identity ? "You" : "Agent";
        setCaptions((c) => {
          const next = [...c];
          for (const s of segments) {
            const i = next.findIndex((x) => x.id === s.id);
            if (i >= 0) next[i] = { ...next[i]!, text: s.text };
            else next.push({ id: s.id, role, text: s.text });
          }
          return next.slice(-30);
        });
      });
      room.on(RoomEvent.Disconnected, () => { setStatus("idle"); roomRef.current = null; });
      await room.connect(join.serverUrl, join.token);
      await room.localParticipant.setMicrophoneEnabled(true);
      setStatus("live");
    } catch (e) {
      setStatus("idle");
      toast.error(e instanceof Error ? e.message : "Could not start the call");
    }
  }

  async function end() {
    setStatus("ending");
    await roomRef.current?.disconnect();
  }

  const active = status !== "idle";
  return (
    <GlassCard >
      <div className="flex items-center justify-between">
        <h2 className="font-semibold text-realtime">Test call</h2>
        <SystemLabel tone={status === "live" ? "live" : status === "connecting" ? "warn" : "muted"} dot={status === "live"}>
          {status === "live" ? "Live" : status}
        </SystemLabel>
      </div>
      <p className="mt-1 text-xs text-muted-foreground">Try your saved draft in a test call. Save first after changes.</p>
      <p className="mt-4 font-pixel text-realtime/70">RT · Session</p>
      <div className="my-3 flex h-12 items-end justify-center gap-1">
        {Array.from({ length: 24 }).map((_, i) => (
          <span key={i} className={`w-1.5 rounded-full bg-realtime ${status === "live" ? "animate-pulse" : "opacity-30"}`}
            style={{ height: `${20 + ((i * 37) % 80)}%`, animationDelay: `${i * 60}ms` }} />
        ))}
      </div>
      {active ? (
        <Button variant="destructive" className="w-full rounded-full" onClick={end} disabled={status === "ending"}><PhoneOff className="h-4 w-4" /> End call</Button>
      ) : (
        <Button className="w-full rounded-full" onClick={begin}><Mic className="h-4 w-4" /> Start test call</Button>
      )}
      <div ref={audioBox} hidden />
      {captions.length > 0 && (
        <div className="mt-4 max-h-64 space-y-2 overflow-y-auto text-sm">
          {captions.map((c) => (
            <p key={c.id}><span className={c.role === "You" ? "text-primary" : "text-realtime"}>{c.role}:</span> {c.text}</p>
          ))}
        </div>
      )}
    </GlassCard>
  );
}
