// Readiness checks for agents and workflows that use tools, plus workflow version publishing.
import { asGraph } from "../workflow-graph";
import type { JsonSchema } from "./schema";

async function admin() {
  return (await import("@/integrations/supabase/client.server")).supabaseAdmin;
}

async function latestApprovals(revisionIds: string[]) {
  const db = await admin();
  const map = new Map<string, { status: string; allowed_contexts: string[]; risk_class: string; confirmation_minimum: string }>();
  if (!revisionIds.length) return map;
  const { data } = await db.from("tool_approvals").select("tool_revision_id, status, allowed_contexts, risk_class, confirmation_minimum, created_at").in("tool_revision_id", revisionIds).order("created_at", { ascending: false });
  for (const a of data ?? []) if (!map.has(a.tool_revision_id)) map.set(a.tool_revision_id, a);
  return map;
}

export type AgentTool = { toolId: string; revisionId: string; name: string; description: string; schema: JsonSchema; always: boolean };

/** Enabled tools for an agent, at the revision the agent was pinned to. */
export async function loadAgentTools(workspaceId: string, agentId: string) {
  const db = await admin();
  const { data: bindings } = await db.from("agent_tool_bindings").select("tool_id, tool_revision_id, confirmation_mode, requirement").eq("agent_id", agentId).eq("workspace_id", workspaceId).eq("enabled", true);
  if (!bindings?.length) return { tools: [] as AgentTool[], bindings: [], defs: [], revs: [], connectors: [] };
  const toolIds = bindings.map((b) => b.tool_id);
  const [{ data: defs }, { data: revs }] = await Promise.all([
    db.from("tool_definitions").select("id, stable_slug, state, current_revision_id, connector_id").in("id", toolIds),
    db.from("tool_revisions").select("id, display_name, description, input_schema").in("id", bindings.map((b) => b.tool_revision_id)),
  ]);
  const { data: connectors } = await db.from("tool_connectors").select("id, display_name, admin_enabled, archived_at, health").in("id", (defs ?? []).map((d) => d.connector_id));
  const tools: AgentTool[] = bindings.flatMap((b) => {
    const d = defs?.find((x) => x.id === b.tool_id), r = revs?.find((x) => x.id === b.tool_revision_id);
    return d && r ? [{ toolId: d.id, revisionId: r.id, name: d.stable_slug, description: r.description || r.display_name, schema: r.input_schema as JsonSchema, always: b.confirmation_mode === "always" }] : [];
  });
  return { tools, bindings, defs: defs ?? [], revs: revs ?? [], connectors: connectors ?? [] };
}

export async function toolProblemsFor(workspaceId: string, agentId: string) {
  const { bindings, defs, connectors } = await loadAgentTools(workspaceId, agentId);
  const approvals = await latestApprovals(bindings.map((b) => b.tool_revision_id));
  const problems: string[] = [];
  for (const b of bindings) {
    const d = defs.find((x) => x.id === b.tool_id);
    const name = d?.stable_slug ?? "A tool";
    if (!d || d.state !== "active") { problems.push(`${name} was removed. Detach it on the Tools tab.`); continue; }
    const c = connectors.find((x) => x.id === d.connector_id);
    if (!c || c.archived_at) problems.push(`${name}: its connection was removed.`);
    else if (!c.admin_enabled) problems.push(`${name}: its connection "${c.display_name}" is paused.`);
    else if (c.health === "auth_invalid" || c.health === "auth_forbidden") problems.push(`${name}: update the credentials for "${c.display_name}".`);
    if (d.current_revision_id !== b.tool_revision_id) problems.push(`${name} changed since you attached it. Review the new version on the Tools page, then reattach it.`);
    const a = approvals.get(b.tool_revision_id);
    if (!a || a.status !== "approved") problems.push(`${name} is not approved yet. Review it on the Tools page.`);
    else if (!a.allowed_contexts.includes("voice_session")) problems.push(`${name} is not allowed on calls. Change where it can run on the Tools page.`);
    else if (a.risk_class === "restricted") problems.push(`${name} is marked restricted and cannot be used.`);
  }
  return problems;
}

/** Saves the workflow's current graph as a new immutable version with pinned tool revisions. */
export async function publishWorkflowVersion(workflowId: string, userId: string | null) {
  const db = await admin();
  const { data: wf } = await db.from("workflows").select("id, workspace_id, steps").eq("id", workflowId).single();
  if (!wf) throw new Error("Workflow not found");
  const graph = asGraph(wf.steps);
  const toolNodes = graph.nodes.filter((n) => n.type === "action" && n.kind === "call_tool" && n.value);
  const { data: defs } = toolNodes.length ? await db.from("tool_definitions").select("id, stable_slug, state, current_revision_id").eq("workspace_id", wf.workspace_id).in("id", toolNodes.map((n) => n.value!)) : { data: [] };
  const approvals = await latestApprovals((defs ?? []).map((d) => d.current_revision_id).filter(Boolean) as string[]);
  const pins: { step_id: string; tool_revision_id: string }[] = [];
  for (const n of toolNodes) {
    const d = defs?.find((x) => x.id === n.value);
    if (!d || d.state !== "active" || !d.current_revision_id) throw new Error("A tool in this workflow is no longer available. Pick another one.");
    const a = approvals.get(d.current_revision_id);
    if (!a || a.status !== "approved") throw new Error(`${d.stable_slug} is not approved yet. Review it on the Tools page first.`);
    if (!a.allowed_contexts.includes("workflow")) throw new Error(`${d.stable_slug} is not allowed in workflows. Change where it can run on the Tools page.`);
    if (a.risk_class !== "read" || a.confirmation_minimum !== "none") throw new Error(`${d.stable_slug} needs someone to confirm it, so it can only run during a call, not in a workflow.`);
    pins.push({ step_id: n.id, tool_revision_id: d.current_revision_id });
  }
  const { data: last } = await db.from("workflow_versions").select("version").eq("workflow_id", wf.id).order("version", { ascending: false }).limit(1).maybeSingle();
  const version = (last?.version ?? 0) + 1;
  const { data: v, error } = await db.from("workflow_versions").insert({ workflow_id: wf.id, workspace_id: wf.workspace_id, version, graph: graph as never, published_by: userId }).select("id").single();
  if (error || !v) throw new Error("Could not save the workflow version");
  if (pins.length) await db.from("workflow_tool_bindings").insert(pins.map((p) => ({ ...p, workflow_version_id: v.id, workspace_id: wf.workspace_id })));
  const { emitEvent } = await import("../events.server");
  await emitEvent(wf.workspace_id, "workflow.published", { workflow_id: wf.id, version });
  return { id: v.id, version };
}
