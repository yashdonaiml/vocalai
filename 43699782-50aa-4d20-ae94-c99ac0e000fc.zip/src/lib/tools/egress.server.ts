// Application egress guard (spec 14.2). HTTPS:443 only, DNS checked twice, private ranges blocked,
// no redirects, byte and time limits. Residual risk recorded for Security Gate A.
export class EgressError extends Error {
  constructor(public code: "EGRESS_DENIED" | "TIMEOUT" | "RESPONSE_INVALID", message: string) { super(message); }
}

const BLOCKED_HOSTS = /(^|\.)(localhost|local|internal|lan|home|corp|supabase\.co|lovable\.cloud|lovable\.app)$/i;

function ipv4Blocked(ip: string): boolean {
  const p = ip.split(".").map(Number);
  if (p.length !== 4 || p.some((n) => Number.isNaN(n))) return true;
  const [a, b] = p as [number, number, number, number];
  return a === 0 || a === 10 || a === 127 || a >= 224 ||
    (a === 100 && b >= 64 && b <= 127) || (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) ||
    (a === 192 && b === 0) || (a === 198 && (b === 18 || b === 19));
}
function ipv6Blocked(ip: string): boolean {
  const s = ip.toLowerCase();
  if (s === "::" || s === "::1") return true;
  if (s.startsWith("fc") || s.startsWith("fd") || s.startsWith("fe8") || s.startsWith("fe9") || s.startsWith("fea") || s.startsWith("feb") || s.startsWith("ff")) return true;
  const mapped = s.match(/::ffff:(\d+\.\d+\.\d+\.\d+)$/);
  return mapped ? ipv4Blocked(mapped[1]!) : false;
}
const isIp = (h: string) => /^\d+\.\d+\.\d+\.\d+$/.test(h) || h.includes(":");

async function resolve(host: string): Promise<string[]> {
  const out: string[] = [];
  for (const type of ["A", "AAAA"]) {
    const r = await fetch(`https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(host)}&type=${type}`, { headers: { accept: "application/dns-json" } });
    if (!r.ok) continue;
    const j = (await r.json()) as { Answer?: { type: number; data: string }[] };
    for (const a of j.Answer ?? []) if (a.type === 1 || a.type === 28) out.push(a.data);
  }
  return out;
}

export async function assertEgressAllowed(rawUrl: string): Promise<URL> {
  let url: URL;
  try { url = new URL(rawUrl); } catch { throw new EgressError("EGRESS_DENIED", "Invalid address"); }
  if (url.protocol !== "https:") throw new EgressError("EGRESS_DENIED", "Only HTTPS is allowed");
  if (url.port && url.port !== "443") throw new EgressError("EGRESS_DENIED", "Only port 443 is allowed");
  if (url.username || url.password) throw new EgressError("EGRESS_DENIED", "Credentials in the address are not allowed");
  const host = url.hostname.replace(/^\[|\]$/g, "");
  if (isIp(host) || BLOCKED_HOSTS.test(host)) throw new EgressError("EGRESS_DENIED", "Destination is not allowed");
  const [first, second] = await Promise.all([resolve(host), resolve(host)]);
  if (!first.length) throw new EgressError("EGRESS_DENIED", "Destination could not be resolved");
  const blocked = (ip: string) => (ip.includes(":") ? ipv6Blocked(ip) : ipv4Blocked(ip));
  if ([...first, ...second].some(blocked)) throw new EgressError("EGRESS_DENIED", "Destination resolves to a private address");
  if (first.some(blocked) !== second.some(blocked)) throw new EgressError("EGRESS_DENIED", "Destination resolution changed");
  return url;
}

export async function guardedFetch(rawUrl: string, init: { method: string; headers: Headers; body?: string | undefined; timeoutMs: number; maxBytes: number; signal?: AbortSignal | undefined }) {
  const url = await assertEgressAllowed(rawUrl);
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort("timeout"), init.timeoutMs);
  init.signal?.addEventListener("abort", () => ctrl.abort("cancelled"));
  try {
    const res = await fetch(url, { method: init.method, headers: init.headers, ...(init.body !== undefined ? { body: init.body } : {}), redirect: "manual", signal: ctrl.signal });
    if (res.status >= 300 && res.status < 400) throw new EgressError("RESPONSE_INVALID", "Redirects are not followed");
    const reader = res.body?.getReader();
    const chunks: Uint8Array[] = [];
    let total = 0;
    while (reader) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.length;
      if (total > init.maxBytes) { await reader.cancel(); throw new EgressError("RESPONSE_INVALID", "Reply was too large"); }
      chunks.push(value);
    }
    const buf = new Uint8Array(total);
    let o = 0; for (const c of chunks) { buf.set(c, o); o += c.length; }
    return { status: res.status, headers: res.headers, text: new TextDecoder().decode(buf), host: url.hostname };
  } catch (e) {
    if (e instanceof EgressError) throw e;
    if (ctrl.signal.aborted && ctrl.signal.reason === "timeout") throw new EgressError("TIMEOUT", "The tool took too long to reply");
    throw e;
  } finally { clearTimeout(timer); }
}
