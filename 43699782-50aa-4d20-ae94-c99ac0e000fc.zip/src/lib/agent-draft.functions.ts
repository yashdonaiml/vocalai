import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// Builder assistant: drafts an agent from a plain description. Platform capability, like Jev.
export const draftAgent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ description: z.string().trim().min(10).max(2000), language: z.string().max(40).default("English") }).parse(d))
  .handler(async ({ data }) => {
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) throw new Error("AI drafting is not available right now.");
    const prompt = `Draft a phone voice agent for this business. Description: """${data.description}"""
Language: ${data.language}.
Return only JSON with keys: name (max 60 chars), description (one sentence), persona (one sentence), instructions (clear rules, max 1500 chars), greeting (one sentence the agent says first), guardrails (one or two sentences), handoff (one sentence), steps (array of 3 to 6 objects {title, say} describing the call in order; the last one wraps up).
Never invent prices, hours, addresses or policies; tell the agent to use its knowledge for facts.`;
    const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${key}` },
      body: JSON.stringify({ model: "openai/gpt-6-astra", input: prompt, text: { format: { type: "json_object" } } }),
      signal: AbortSignal.timeout(45000),
    });
    if (res.status === 429) throw new Error("Too many requests. Try again in a minute.");
    if (res.status === 402) throw new Error("AI credits are used up. Add credits to keep drafting.");
    if (!res.ok) throw new Error("The draft could not be created. Try again.");
    const body = (await res.json()) as { output_text?: string; output?: { content?: { type: string; text?: string }[] }[] };
    const text = body.output_text ?? (body.output ?? []).flatMap((o) => o.content ?? []).filter((c) => c.type === "output_text").map((c) => c.text ?? "").join("");
    let raw: { [k: string]: unknown } & Partial<Record<"name" | "description" | "persona" | "instructions" | "greeting" | "guardrails" | "handoff" | "steps", unknown>>;
    try { raw = JSON.parse(text.replace(/^```(json)?|```$/g, "").trim()); } catch { throw new Error("The draft came back unreadable. Try again."); }
    const str = (v: unknown, max: number) => (typeof v === "string" ? v.replace(/\s*[—–]\s*/g, ", ").replace(/…/g, ".").trim().slice(0, max) : "");
    const steps = (Array.isArray(raw.steps) ? raw.steps : []).slice(0, 6).map((s) => ({ title: str((s as { title?: unknown })?.title, 60) || "Step", say: str((s as { say?: unknown })?.say, 600) }));
    return {
      name: str(raw.name, 60) || "New agent",
      description: str(raw.description, 300),
      persona: str(raw.persona, 300),
      instructions: str(raw.instructions, 12000),
      greeting: str(raw.greeting, 400),
      guardrails: str(raw.guardrails, 600),
      handoff: str(raw.handoff, 400),
      steps,
    };
  });
