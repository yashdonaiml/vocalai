import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type Ctx = { supabase: { rpc: (fn: "is_workspace_member", a: { _ws: string; _min?: "admin" | "member" }) => PromiseLike<{ data: boolean | null }> }; userId: string };

async function requireWs(context: Ctx, ws: string, min: "admin" | "member" = "member") {
  const { data } = await context.supabase.rpc("is_workspace_member", { _ws: ws, _min: min });
  if (!data) throw new Error(min === "admin" ? "Only organization owners and admins can do this" : "Not a workspace member");
}

async function audit(ws: string, actor: string, action: string, target: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin.from("workspaces").select("org_id").eq("id", ws).single();
  await supabaseAdmin.from("audit_events").insert({ org_id: data?.org_id ?? null, workspace_id: ws, actor_id: actor, action, target });
}

async function timedFetch(url: string, init: RequestInit, timeoutMs: number) {
  const started = Date.now();
  try {
    const res = await fetch(url, { ...init, signal: AbortSignal.timeout(timeoutMs) });
    const body = (await res.text()).slice(0, 2000);
    return { status: res.status, body, durationMs: Date.now() - started, error: null as string | null };
  } catch (e) {
    return { status: null as number | null, body: "", durationMs: Date.now() - started, error: e instanceof Error ? e.message : "Request failed" };
  }
}

export const updateTool = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({
      id: z.string().uuid(),
      description: z.string().max(500),
      parameters: z.string().max(5000),
      endpointUrl: z.string().url().startsWith("https://"),
      method: z.enum(["GET", "POST"]),
      timeoutMs: z.number().int().min(500).max(30000),
      authHeader: z.string().max(1000).optional(),
      clearAuth: z.boolean().optional(),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { data: tool } = await context.supabase.from("tools").select("id, workspace_id").eq("id", data.id).maybeSingle();
    if (!tool) throw new Error("Tool not found");
    await requireWs(context as never, tool.workspace_id);
    let parameters: unknown;
    try { parameters = JSON.parse(data.parameters); } catch { throw new Error("Parameters must be valid JSON Schema"); }
    const { encryptSecret } = await import("./crypto.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const patch: Record<string, unknown> = {
      description: data.description, parameters, endpoint_url: data.endpointUrl, method: data.method, timeout_ms: data.timeoutMs,
    };
    if (data.authHeader) { patch["auth_hint"] = `…${data.authHeader.slice(-4)}`; patch["auth_ciphertext"] = await encryptSecret(data.authHeader); }
    else if (data.clearAuth) { patch["auth_hint"] = null; patch["auth_ciphertext"] = null; }
    const { error } = await supabaseAdmin.from("tools").update(patch as never).eq("id", tool.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const testTool = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid(), input: z.string().max(5000) }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: tool } = await context.supabase.from("tools").select("id, workspace_id, name, endpoint_url, method, timeout_ms").eq("id", data.id).maybeSingle();
    if (!tool) throw new Error("Tool not found");
    await requireWs(context as never, tool.workspace_id);
    let args: Record<string, unknown>;
    try { args = JSON.parse(data.input || "{}"); } catch { throw new Error("Sample input must be valid JSON"); }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: secret } = await supabaseAdmin.from("tools").select("auth_ciphertext").eq("id", tool.id).single();
    const headers: Record<string, string> = { "content-type": "application/json", "x-aviroh-test": "1" };
    if (secret?.auth_ciphertext) {
      const { decryptSecret } = await import("./crypto.server");
      headers["authorization"] = await decryptSecret(secret.auth_ciphertext);
    }
    let url = tool.endpoint_url;
    if (tool.method === "GET") {
      const u = new URL(url);
      for (const [k, v] of Object.entries(args)) u.searchParams.set(k, String(v));
      url = u.toString();
    }
    return timedFetch(url, { method: tool.method, headers, body: tool.method === "POST" ? JSON.stringify(args) : null }, tool.timeout_ms);
  });

export const WEBHOOK_EVENTS = ["conversation.started", "conversation.ended", "deployment.created", "agent.published", "eval.completed", "knowledge.indexed"] as const;

export const createWebhook = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ workspaceId: z.string().uuid(), url: z.string().url().startsWith("https://"), events: z.array(z.enum(WEBHOOK_EVENTS)).min(1) }).parse(d))
  .handler(async ({ data, context }) => {
    await requireWs(context as never, data.workspaceId, "admin");
    const rand = new Uint8Array(24);
    crypto.getRandomValues(rand);
    const secret = `whsec_${Array.from(rand).map((b) => b.toString(16).padStart(2, "0")).join("")}`;
    const { encryptSecret } = await import("./crypto.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("webhook_endpoints").insert({
      workspace_id: data.workspaceId, url: data.url, events: data.events, secret_hint: `…${secret.slice(-4)}`,
      secret_ciphertext: await encryptSecret(secret), created_by: context.userId,
    });
    if (error) throw new Error(error.message);
    await audit(data.workspaceId, context.userId, "webhook.created", data.url);
    return { secret };
  });

async function loadEndpoint(context: Ctx & { supabase: unknown }, id: string) {
  const sb = context.supabase as unknown as { from: (t: "webhook_endpoints") => { select: (s: string) => { eq: (c: string, v: string) => { maybeSingle: () => PromiseLike<{ data: { id: string; workspace_id: string; url: string; events: string[] } | null }> } } } };
  const { data } = await sb.from("webhook_endpoints").select("id, workspace_id, url, events").eq("id", id).maybeSingle();
  if (!data) throw new Error("Webhook not found");
  await requireWs(context, data.workspace_id, "admin");
  return data;
}

export const setWebhookEnabled = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid(), enabled: z.boolean() }).parse(d))
  .handler(async ({ data, context }) => {
    const ep = await loadEndpoint(context as never, data.id);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("webhook_endpoints").update({ enabled: data.enabled }).eq("id", ep.id);
    await audit(ep.workspace_id, context.userId, data.enabled ? "webhook.enabled" : "webhook.disabled", ep.url);
    return { ok: true };
  });

export const deleteWebhook = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const ep = await loadEndpoint(context as never, data.id);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("webhook_endpoints").delete().eq("id", ep.id);
    await audit(ep.workspace_id, context.userId, "webhook.deleted", ep.url);
    return { ok: true };
  });

// Sends a signed test event so customers can verify their receiver and signature check.
export const testWebhook = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const ep = await loadEndpoint(context as never, data.id);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row } = await supabaseAdmin.from("webhook_endpoints").select("secret_ciphertext").eq("id", ep.id).single();
    const { decryptSecret, hmacHex } = await import("./crypto.server");
    const secret = await decryptSecret(row!.secret_ciphertext);
    const event = "test.ping";
    const ts = Math.floor(Date.now() / 1000).toString();
    const body = JSON.stringify({ type: event, created_at: new Date().toISOString(), data: { message: "Test delivery from aviroh" } });
    const sig = await hmacHex(secret, `${ts}.${body}`);
    const r = await timedFetch(ep.url, { method: "POST", headers: { "content-type": "application/json", "x-aviroh-timestamp": ts, "x-aviroh-signature": sig }, body }, 10000);
    await supabaseAdmin.from("webhook_deliveries").insert({ endpoint_id: ep.id, workspace_id: ep.workspace_id, event, status: r.status, error: r.error, duration_ms: r.durationMs });
    return { status: r.status, error: r.error, durationMs: r.durationMs };
  });

const PROVIDER_PROBES: Record<string, (k: string) => [string, Record<string, string>]> = {
  openai: (k) => ["https://api.openai.com/v1/models", { authorization: `Bearer ${k}` }],
  anthropic: (k) => ["https://api.anthropic.com/v1/models", { "x-api-key": k, "anthropic-version": "2023-06-01" }],
  google: (k) => [`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(k)}`, {}],
  deepgram: (k) => ["https://api.deepgram.com/v1/projects", { authorization: `Token ${k}` }],
  elevenlabs: (k) => ["https://api.elevenlabs.io/v1/user", { "xi-api-key": k }],
  cartesia: (k) => ["https://api.cartesia.ai/voices", { "x-api-key": k, "cartesia-version": "2024-06-10" }],
};

// Verifies a stored key with a read-only call to the provider. Never returns the key.
export const testProviderKey = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: row } = await context.supabase.from("provider_accounts").select("id, org_id, provider").eq("id", data.id).maybeSingle();
    if (!row) throw new Error("Key not found");
    const { data: ok } = await context.supabase.rpc("is_org_member", { _org: row.org_id, _min: "admin" });
    if (!ok) throw new Error("Only organization admins can test keys");
    const probe = PROVIDER_PROBES[row.provider];
    if (!probe) throw new Error("No test available for this provider");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: s } = await supabaseAdmin.from("provider_accounts").select("key_ciphertext").eq("id", row.id).single();
    const { decryptSecret } = await import("./crypto.server");
    const [url, headers] = probe(await decryptSecret(s!.key_ciphertext));
    const r = await timedFetch(url, { method: "GET", headers }, 10000);
    return { ok: r.status !== null && r.status < 300, status: r.status, error: r.error, durationMs: r.durationMs };
  });
