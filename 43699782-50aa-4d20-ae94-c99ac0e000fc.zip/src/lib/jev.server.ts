// Jev (TypeSafe System One) typed decisions via the Lovable AI Gateway.
// One optional capability: fast, cheap judgments (choice/score/noul) for workflows,
// tagging, evals and knowledge reranking. Never hard-wired into the agent path.
const ENDPOINT = "https://ai.gateway.lovable.dev/v1/systemone";
const MODEL = "typesafe/jev-latest";

export type JevQuestion =
  | { type: "choice"; instructions: string | Record<string, unknown>; criteria: Record<string, string | Record<string, unknown>> }
  | { type: "score"; instructions: string | Record<string, unknown>; criteria: (string | Record<string, unknown>)[] }
  | { type: "noul"; instructions: string | Record<string, unknown>; criteria?: { true: string; false: string } };

export type JevAnswer = {
  choice?: string;
  score?: number;
  noul?: number;
  confidence?: number;
  probabilities?: Record<string, number>;
};

export class JevUnavailableError extends Error {
  constructor() {
    super("AI checks are not available right now.");
    this.name = "JevUnavailableError";
  }
}

// Ask several independent questions over the same state in one request.
export async function askJev(state: unknown, questions: Record<string, JevQuestion>): Promise<Record<string, JevAnswer>> {
  const key = process.env["LOVABLE_API_KEY"];
  if (!key) throw new JevUnavailableError();
  const res = await fetch(ENDPOINT, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${key}`,
      "x-lovable-aig-sdk": "fetch",
    },
    body: JSON.stringify({ model: MODEL, state, questions }),
    signal: AbortSignal.timeout(20000),
  });
  if (!res.ok) {
    if (res.status === 401) throw new JevUnavailableError();
    const text = await res.text().catch(() => "");
    throw new Error(`AI check failed (${res.status})${text ? `: ${text.slice(0, 200)}` : ""}`);
  }
  const json = (await res.json()) as { answers?: Record<string, JevAnswer> };
  if (!json.answers) throw new Error("AI check returned no answers.");
  return json.answers;
}

// Yes/no judgment over call content. Returns the probability that the condition holds.
export async function jevNoul(question: string, state: { summary?: string | null; transcript?: string }): Promise<number> {
  const answers = await askJev(state, {
    check: {
      type: "noul",
      instructions: {
        question,
        evidence: "Answer using only the call summary and transcript in the state. If the evidence is missing or unclear, answer based on what is present.",
      },
      criteria: { true: "The evidence supports the statement.", false: "The evidence does not support the statement." },
    },
  });
  const p = answers["check"]?.noul;
  if (typeof p !== "number") throw new Error("AI check returned no answer.");
  return p;
}

// Pick the best-fitting option from a workspace-defined set. Returns null when nothing fits well.
export async function jevChoice(
  question: string,
  options: Record<string, string>,
  state: { summary?: string | null; transcript?: string },
  minConfidence = 0.4,
): Promise<{ choice: string; confidence: number } | null> {
  const answers = await askJev(state, {
    pick: {
      type: "choice",
      instructions: {
        question,
        evidence: "Answer using only the call summary and transcript in the state. Pick 'none' when no option clearly fits.",
      },
      criteria: { ...options, none: "No option clearly fits this call." },
    },
  });
  const a = answers["pick"];
  if (!a?.choice || a.choice === "none") return null;
  const confidence = typeof a.confidence === "number" ? a.confidence : 1;
  if (confidence < minConfidence) return null;
  return { choice: a.choice, confidence };
}
