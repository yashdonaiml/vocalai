// Provider registry: resolves credentials (workspace BYOK first, then platform key) and
// exposes capability adapters. The only place that talks to AI vendors from the control plane.
import { PROVIDERS, type ProviderId } from "./catalog";
import { decryptSecret } from "../crypto.server";

export type Credential = { provider: ProviderId; apiKey: string; source: "byok" | "platform" };

export async function resolveCredential(orgId: string, provider: ProviderId): Promise<Credential> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("provider_accounts")
    .select("key_ciphertext")
    .eq("org_id", orgId)
    .eq("provider", provider)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (data?.key_ciphertext) return { provider, apiKey: await decryptSecret(data.key_ciphertext), source: "byok" };
  const env = PROVIDERS.find((p) => p.id === provider)?.env;
  const key = env ? process.env[env] : undefined;
  if (!key) throw new Error(`No ${provider} key: add one under Models & Keys`);
  return { provider, apiKey: key, source: "platform" };
}

export function platformKeyStatus() {
  return PROVIDERS.map((p) => ({ provider: p.id, configured: Boolean(process.env[p.env]) }));
}

// ---- Embedding adapters (3072-dim to match the vector column) ----
export interface EmbeddingProvider {
  embed(texts: string[]): Promise<number[][]>;
}

function openaiEmbeddings(apiKey: string, model: string): EmbeddingProvider {
  return {
    async embed(texts) {
      const out: number[][] = [];
      for (let i = 0; i < texts.length; i += 64) {
        const res = await fetch("https://api.openai.com/v1/embeddings", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
          body: JSON.stringify({ model, input: texts.slice(i, i + 64), dimensions: 3072 }),
        });
        if (!res.ok) throw new Error(`OpenAI embeddings failed (${res.status})`);
        const j = (await res.json()) as { data: { embedding: number[]; index: number }[] };
        j.data.sort((a, b) => a.index - b.index).forEach((d) => out.push(d.embedding));
      }
      return out;
    },
  };
}

function googleEmbeddings(apiKey: string, model: string): EmbeddingProvider {
  return {
    async embed(texts) {
      const out: number[][] = [];
      for (let i = 0; i < texts.length; i += 50) {
        const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:batchEmbedContents?key=${apiKey}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            requests: texts.slice(i, i + 50).map((t) => ({
              model: `models/${model}`,
              content: { parts: [{ text: t }] },
              outputDimensionality: 3072,
            })),
          }),
        });
        if (!res.ok) throw new Error(`Gemini embeddings failed (${res.status})`);
        const j = (await res.json()) as { embeddings: { values: number[] }[] };
        j.embeddings.forEach((e) => out.push(e.values));
      }
      return out;
    },
  };
}

export async function embeddingProvider(orgId: string, provider: string, model: string): Promise<EmbeddingProvider> {
  if (provider !== "openai" && provider !== "google") throw new Error(`${provider} has no embedding adapter`);
  const cred = await resolveCredential(orgId, provider);
  return provider === "openai" ? openaiEmbeddings(cred.apiKey, model) : googleEmbeddings(cred.apiKey, model);
}
