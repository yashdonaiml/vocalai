// Runtime-facing control-plane logic, called by the signed /api/public/runtime/* routes.
import { hmacHex } from "../crypto.server";
import { normalizeConfig } from "../agent-config";

// Verifies `x-aviroh-timestamp` + `x-aviroh-signature` = hex(HMAC(secret, ts + "." + body)).
export async function verifyRuntimeRequest(request: Request): Promise<unknown> {
  const secret = process.env["RUNTIME_SHARED_SECRET"];
  if (!secret) throw new Response("Runtime not configured", { status: 503 });
  const ts = request.headers.get("x-aviroh-timestamp") ?? "";
  const sig = request.headers.get("x-aviroh-signature") ?? "";
  const body = await request.text();
  if (!ts || Math.abs(Date.now() / 1000 - Number(ts)) > 300) throw new Response("Stale request", { status: 401 });
  const expected = await hmacHex(secret, `${ts}.${body}`);
  if (sig.length !== expected.length) throw new Response("Bad signature", { status: 401 });
  let diff = 0;
  for (let i = 0; i < sig.length; i++) diff |= sig.charCodeAt(i) ^ expected.charCodeAt(i);
  if (diff !== 0) throw new Response("Bad signature", { status: 401 });
  return body ? JSON.parse(body) : {};
}

export async function runtimeHandler(request: Request, fn: (body: unknown) => Promise<unknown>) {
  try {
    const body = await verifyRuntimeRequest(request);
    return Response.json(await fn(body));
  } catch (e) {
    if (e instanceof Response) return e;
    console.error(e);
    return Response.json({ error: e instanceof Error ? e.message : "Runtime request failed" }, { status: 400 });
  }
}

async function admin() {
  return (await import("@/integrations/supabase/client.server")).supabaseAdmin;
}

async function sessionRow(sessionId: string) {
  const db = await admin();
  const { data } = await db
    .from("conversations")
    .select("id, workspace_id, agent_id, agent_version, deployment_id, environment_id, started_at, workspaces(org_id)")
    .eq("id", sessionId)
    .single();
  if (!data) throw new Error("Session not found");
  return { ...data, org_id: (data.workspaces as unknown as { org_id: string }).org_id };
}


// Resolves the bundle + credentials for a session. Inbound phone calls create their session here.
export async function openSession(body: { session_id?: string; phone_number_id?: string; caller?: string; session_ref?: string }) {
  const db = await admin();
  let sessionId = body.session_id;
  let bundleId: string | null = null;
  if (!sessionId && body.phone_number_id) {
    const { data: num } = await db.from("phone_numbers").select("workspace_id, agent_id, environment_id").eq("id", body.phone_number_id).single();
    if (!num?.agent_id || !num.environment_id) throw new Error("Number is not routed to an agent");
    const { data: dep } = await db
      .from("deployments")
      .select("id, agent_version, bundle_id")
      .eq("agent_id", num.agent_id)
      .eq("environment_id", num.environment_id)
      .eq("status", "active")
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (!dep) throw new Error("No active deployment for this number");
    const { data: conv } = await db
      .from("conversations")
      .insert({
        workspace_id: num.workspace_id,
        agent_id: num.agent_id,
        agent_version: dep.agent_version,
        deployment_id: dep.id,
        environment_id: num.environment_id,
        channel: "pstn",
        status: "active",
        session_ref: body.session_ref ?? null,
        summary: body.caller ? `Caller ${body.caller}` : null,
      })
      .select("id")
      .single();
    sessionId = conv!.id;
    bundleId = dep.bundle_id;
    void (await import("../workflows.server")).dispatchWorkflows(num.workspace_id, "call.started", conv!.id);
  }
  if (!sessionId) throw new Error("session_id or phone_number_id required");
  const s = await sessionRow(sessionId);
  if (!bundleId) {
    if (s.deployment_id) {
      bundleId = (await db.from("deployments").select("bundle_id").eq("id", s.deployment_id).single()).data?.bundle_id ?? null;
    } else {
      bundleId = (await db.from("runtime_bundles").select("id").eq("agent_id", s.agent_id!).is("environment_id", null)
        .order("created_at", { ascending: false }).limit(1).single()).data?.id ?? null;
    }
  }
  if (!bundleId) throw new Error("No bundle for session");
  const { data: b } = await db.from("runtime_bundles").select("bundle, checksum").eq("id", bundleId).single();
  const bundle = b!.bundle as { runtime: unknown };
  const { bundleCredentials } = await import("./bundle.server");
  const credentials = await bundleCredentials(s.org_id, normalizeConfig({ runtime: bundle.runtime }).runtime);
  return { session_id: sessionId, checksum: b!.checksum, bundle, credentials };
}

export async function retrieve(body: { session_id: string; query: string }) {
  const s = await sessionRow(body.session_id);
  const db = await admin();
  const kbIds = ((await db.from("agent_knowledge_bases").select("knowledge_base_id").eq("agent_id", s.agent_id!)).data ?? []).map((r) => r.knowledge_base_id);
  const { searchKnowledge } = await import("../knowledge.server");
  const hits = await searchKnowledge(kbIds, String(body.query).slice(0, 500), 5);
  return { results: hits.map((h) => ({ content: h.content, score: h.similarity })) };
}

export async function callTool(body: { session_id: string; tool: string; args: unknown }) {
  const s = await sessionRow(body.session_id);
  const db = await admin();
  const { data: tool } = await db
    .from("tools")
    .select("id, name, endpoint_url, method, timeout_ms, auth_ciphertext")
    .eq("workspace_id", s.workspace_id)
    .eq("name", body.tool)
    .maybeSingle();
  if (!tool) throw new Error("Unknown tool");
  const headers: Record<string, string> = { "Content-Type": "application/json", "X-Aviroh-Session": s.id };
  if (tool.auth_ciphertext) headers["Authorization"] = await (await import("../crypto.server")).decryptSecret(tool.auth_ciphertext);
  const started = Date.now();
  const url = tool.method === "GET" ? `${tool.endpoint_url}?${new URLSearchParams(body.args as Record<string, string>)}` : tool.endpoint_url;
  const res = await fetch(url, {
    method: tool.method,
    headers,
    body: tool.method === "POST" ? JSON.stringify(body.args ?? {}) : null,
    signal: AbortSignal.timeout(tool.timeout_ms),
  });
  const text = (await res.text()).slice(0, 8000);
  await db.from("usage_events").insert({ workspace_id: s.workspace_id, conversation_id: s.id, kind: "tool_call", model: tool.name, quantity: Date.now() - started, unit: "ms" });
  return { ok: res.ok, status: res.status, body: text };
}

type RuntimeEvent =
  | { type: "turn"; role: "user" | "assistant"; content: string }
  | { type: "usage"; kind: string; model: string; quantity: number; unit: string }
  | { type: "end"; reason?: string };

export async function ingestEvents(body: { session_id: string; events: RuntimeEvent[] }) {
  const s = await sessionRow(body.session_id);
  const db = await admin();
  const { count } = await db.from("conversation_turns").select("id", { count: "exact", head: true }).eq("conversation_id", s.id);
  let seq = count ?? 0;
  for (const ev of (body.events ?? []).slice(0, 200)) {
    if (ev.type === "turn" && ev.content?.trim()) {
      await db.from("conversation_turns").insert({ conversation_id: s.id, workspace_id: s.workspace_id, seq: seq++, role: ev.role, content: ev.content.trim().slice(0, 8000) });
      if (ev.role === "user") {
        await db.from("conversations").update({ summary: ev.content.slice(0, 160) }).eq("id", s.id).is("summary", null);
        await (await import("../workflows.server")).dispatchWorkflows(s.workspace_id, "keyword", s.id, ev.content);
      }
    } else if (ev.type === "usage") {
      await db.from("usage_events").insert({ workspace_id: s.workspace_id, conversation_id: s.id, kind: ev.kind, model: ev.model, quantity: ev.quantity, unit: ev.unit });
    } else if (ev.type === "end") {
      const seconds = Math.round((Date.now() - new Date(s.started_at).getTime()) / 1000);
      await db.from("conversations").update({ status: "completed", ended_at: new Date().toISOString(), duration_seconds: seconds }).eq("id", s.id);
      await db.from("usage_events").insert({ workspace_id: s.workspace_id, conversation_id: s.id, kind: "voice_minutes", model: "session", quantity: Math.max(seconds, 1) / 60, unit: "minutes" });
      await (await import("../workflows.server")).dispatchWorkflows(s.workspace_id, "call.ended", s.id);
    }
  }
  return { ok: true };
}
