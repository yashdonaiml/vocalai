// Deployment compiler: agent config + tools + knowledge refs -> immutable runtime bundle.
// The bundle is aviroh's contract with the Runtime Service; it contains no secrets.
import { checksum, effectiveInstructions, normalizeConfig } from "../agent-config";

export const BUNDLE_SCHEMA = "aviroh.bundle/v1";

export async function compileBundle(opts: {
  workspaceId: string;
  agentId: string;
  agentVersion: number | null;
  environmentId: string | null;
  userId: string;
}) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  let rawConfig: unknown;
  if (opts.agentVersion != null) {
    const { data } = await supabaseAdmin.from("agent_versions").select("config").eq("agent_id", opts.agentId).eq("version", opts.agentVersion).single();
    rawConfig = data?.config;
  } else {
    const { data } = await supabaseAdmin.from("agents").select("config").eq("id", opts.agentId).single();
    rawConfig = data?.config;
  }
  if (!rawConfig) throw new Error("Agent configuration not found");
  const config = normalizeConfig(rawConfig);
  const snapshotKbs = (rawConfig as { knowledge_base_ids?: string[] }).knowledge_base_ids;
  const kbIds = snapshotKbs ?? ((await supabaseAdmin.from("agent_knowledge_bases").select("knowledge_base_id").eq("agent_id", opts.agentId)).data ?? []).map((r) => r.knowledge_base_id);
  const { data: toolRows } = await supabaseAdmin
    .from("agent_tools")
    .select("tools(id, name, description, parameters, timeout_ms)")
    .eq("agent_id", opts.agentId);
  const tools = (toolRows ?? []).map((r) => r.tools).filter(Boolean) as unknown as {
    id: string; name: string; description: string; parameters: unknown; timeout_ms: number;
  }[];

  const bundle = {
    schema: BUNDLE_SCHEMA,
    agent: { id: opts.agentId, version: opts.agentVersion },
    workspace_id: opts.workspaceId,
    environment_id: opts.environmentId,
    prompt: {
      persona: config.persona,
      instructions: effectiveInstructions(config),
      greeting: config.greeting,
      language: config.language,
      guardrails: config.guardrails,
      handoff: config.handoff,
    },
    runtime: config.runtime,
    knowledge: { knowledge_base_ids: kbIds, top_k: 5 },
    tools,
  };
  const sum = await checksum(bundle);
  const { data, error } = await supabaseAdmin
    .from("runtime_bundles")
    .insert({
      workspace_id: opts.workspaceId,
      agent_id: opts.agentId,
      agent_version: opts.agentVersion,
      environment_id: opts.environmentId,
      bundle: bundle as never,
      checksum: sum,
      created_by: opts.userId,
    })
    .select("id")
    .single();
  if (error || !data) throw new Error(error?.message ?? "Could not compile bundle");
  return { bundleId: data.id, checksum: sum, bundle };
}

// Provider credentials the runtime needs for this bundle (never persisted in the bundle).
export async function bundleCredentials(orgId: string, runtime: ReturnType<typeof normalizeConfig>["runtime"]) {
  const { resolveCredential } = await import("../providers/registry.server");
  const providers = runtime.mode === "native"
    ? [runtime.realtime.provider]
    : [runtime.stt.provider, runtime.llm.provider, runtime.tts.provider];
  const out: Record<string, string> = {};
  for (const p of new Set(providers)) out[p] = (await resolveCredential(orgId, p)).apiKey;
  return out;
}
