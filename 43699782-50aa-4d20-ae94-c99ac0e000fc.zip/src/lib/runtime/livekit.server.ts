// LiveKit adapter: the media/telephony substrate. Nothing outside this file knows LiveKit terms.
export const RUNTIME_AGENT_NAME = "aviroh-runtime";

function cfg() {
  const url = process.env["LIVEKIT_URL"];
  const key = process.env["LIVEKIT_API_KEY"];
  const secret = process.env["LIVEKIT_API_SECRET"];
  if (!url || !key || !secret) throw new Error("Voice media layer is not configured yet (LiveKit credentials missing)");
  return { url, key, secret, http: url.replace(/^wss?:/, "https:") };
}

export function mediaConfigured() {
  return Boolean(process.env["LIVEKIT_URL"] && process.env["LIVEKIT_API_KEY"] && process.env["LIVEKIT_API_SECRET"]);
}

// Creates a session join grant for a browser participant and dispatches the runtime worker.
export async function createSessionJoin(opts: { sessionRef: string; identity: string; metadata: Record<string, unknown> }) {
  const { url, key, secret } = cfg();
  const { AccessToken } = await import("livekit-server-sdk");
  const { RoomConfiguration, RoomAgentDispatch } = await import("@livekit/protocol");
  const at = new AccessToken(key, secret, { identity: opts.identity, ttl: "15m" });
  at.addGrant({ room: opts.sessionRef, roomJoin: true, canPublish: true, canSubscribe: true });
  at.roomConfig = new RoomConfiguration({
    agents: [new RoomAgentDispatch({ agentName: RUNTIME_AGENT_NAME, metadata: JSON.stringify(opts.metadata) })],
  });
  return { serverUrl: url, token: await at.toJwt() };
}

// Provisions inbound PSTN for a number: SIP inbound trunk + dispatch rule to the runtime.
export async function provisionInboundNumber(opts: { e164: string; numberId: string }) {
  const { http, key, secret } = cfg();
  const { SipClient } = await import("livekit-server-sdk");
  const sip = new SipClient(http, key, secret);
  const trunk = await sip.createSipInboundTrunk(`aviroh-${opts.numberId}`, [opts.e164], { krispEnabled: true });
  const { RoomConfiguration, RoomAgentDispatch } = await import("@livekit/protocol");
  const rule = await sip.createSipDispatchRule(
    { type: "individual", roomPrefix: `pstn-${opts.numberId}-` },
    {
      name: `aviroh-${opts.numberId}`,
      trunkIds: [trunk.sipTrunkId],
      roomConfig: new RoomConfiguration({
        agents: [new RoomAgentDispatch({ agentName: RUNTIME_AGENT_NAME, metadata: JSON.stringify({ phone_number_id: opts.numberId }) })],
      }),
    },
  );
  return { trunkRef: trunk.sipTrunkId, ruleRef: rule.sipDispatchRuleId };
}
