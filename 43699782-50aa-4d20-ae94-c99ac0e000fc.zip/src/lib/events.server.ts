// Event outbox (ENG-TOOLS-001 section 13). domain_events.payload holds IDs and minimal facts only:
// never transcripts, arguments, outputs or personal data. Events are delivered to subscribed
// webhook endpoints right after they are written, and the maintenance job retries any left behind.
async function admin() {
  return (await import("@/integrations/supabase/client.server")).supabaseAdmin;
}

export type DomainEventType = "tool.approved" | "tool.changed" | "tool.call_failed" | "workflow.published" | "connection.unhealthy";

export async function emitEvent(workspaceId: string, type: DomainEventType, payload: Record<string, string | number | boolean | null>) {
  const db = await admin();
  const { data } = await db.from("domain_events").insert({ workspace_id: workspaceId, type, payload: payload as never }).select("id").single();
  if (data) await deliverEvents({ ids: [data.id] }).catch(() => undefined);
}

/** Delivers unprocessed events (oldest first) to enabled webhook endpoints subscribed to the type. */
export async function deliverEvents(opts: { ids?: string[]; limit?: number } = {}) {
  const db = await admin();
  let q = db.from("domain_events").select("id, workspace_id, type, payload, created_at").is("processed_at", null).order("created_at").limit(opts.limit ?? 25);
  if (opts.ids) q = q.in("id", opts.ids);
  const { data: events } = await q;
  const { decryptSecret, hmacHex } = await import("./crypto.server");
  let delivered = 0;
  for (const ev of events ?? []) {
    const { data: eps } = await db.from("webhook_endpoints").select("id, url, events, secret_ciphertext").eq("workspace_id", ev.workspace_id).eq("enabled", true);
    for (const ep of (eps ?? []).filter((e) => (e.events as string[] | null)?.includes(ev.type))) {
      const ts = Math.floor(Date.now() / 1000).toString();
      const body = JSON.stringify({ id: ev.id, type: ev.type, created_at: ev.created_at, data: ev.payload });
      const sig = await hmacHex(await decryptSecret(ep.secret_ciphertext), `${ts}.${body}`);
      const t0 = Date.now();
      let status: number | null = null, error: string | null = null;
      try {
        const res = await fetch(ep.url, { method: "POST", headers: { "content-type": "application/json", "x-aviroh-timestamp": ts, "x-aviroh-signature": sig }, body, signal: AbortSignal.timeout(8000) });
        status = res.status;
      } catch (e) { error = e instanceof Error ? e.message : "Delivery failed"; }
      await db.from("webhook_deliveries").insert({ endpoint_id: ep.id, workspace_id: ev.workspace_id, event: ev.type, status, error, duration_ms: Date.now() - t0 });
      delivered++;
    }
    await db.from("domain_events").update({ processed_at: new Date().toISOString() }).eq("id", ev.id);
  }
  return { events: events?.length ?? 0, delivered };
}
