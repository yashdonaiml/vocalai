// Stealth Conversation Runtime entrypoint (LiveKit Agents worker).
// Session lifecycle: dispatch -> open session (bundle + creds) -> run engine -> stream events -> end.
import { fileURLToPath } from "node:url";
import { cli, defineAgent, llm, voice, WorkerOptions, type JobContext } from "@livekit/agents";
import { z } from "zod";
import { controlPlane, type Bundle } from "./control-plane.js";
import { buildSessionOptions } from "./engines.js";

function systemPrompt(b: Bundle) {
  const p = b.prompt;
  return [
    `You are ${p.persona}`,
    p.instructions,
    `Speak ${p.language}. Replies are spoken aloud: short, natural, no markdown.`,
    `Guardrails: ${p.guardrails}`,
    `Handoff: ${p.handoff}`,
    b.knowledge.knowledge_base_ids.length ? "Always call search_knowledge before stating business facts." : "",
  ].filter(Boolean).join("\n\n");
}

// JSON-schema -> zod (shallow) so registry tools can be exposed to the model.
function toZod(schema: Record<string, unknown>) {
  const props = (schema.properties ?? {}) as Record<string, { type?: string; description?: string }>;
  const shape: Record<string, z.ZodTypeAny> = {};
  for (const [k, v] of Object.entries(props)) {
    const base = v.type === "number" || v.type === "integer" ? z.number() : v.type === "boolean" ? z.boolean() : z.string();
    shape[k] = v.description ? base.describe(v.description) : base;
  }
  return z.object(shape);
}

export default defineAgent({
  entry: async (ctx: JobContext) => {
    await ctx.connect();
    const meta = JSON.parse(ctx.job.metadata || "{}") as { session_id?: string; phone_number_id?: string };
    const caller = [...ctx.room.remoteParticipants.values()][0]?.identity;
    const s = await controlPlane.openSession({ ...meta, caller, session_ref: ctx.room.name });
    const sid = s.session_id;

    const tools: llm.ToolContext = {};
    if (s.bundle.knowledge.knowledge_base_ids.length) {
      tools.search_knowledge = llm.tool({
        description: "Search the business knowledge base. Use before answering factual questions.",
        parameters: z.object({ query: z.string().describe("What to look up") }),
        execute: async ({ query }) => {
          const r = await controlPlane.retrieve(sid, query);
          return r.results.map((x) => x.content).join("\n---\n") || "No relevant information found.";
        },
      });
    }
    for (const t of s.bundle.tools) {
      tools[t.name] = llm.tool({
        description: t.description,
        parameters: toZod(t.parameters),
        execute: async (args) => (await controlPlane.tool(sid, t.name, args)).body,
      });
    }

    const agent = new voice.Agent({ instructions: systemPrompt(s.bundle), tools });
    const session = new voice.AgentSession(await buildSessionOptions(s.bundle, s.credentials));

    // Batch transcript events to the control plane.
    let buffer: unknown[] = [];
    const flush = async () => {
      if (!buffer.length) return;
      const batch = buffer; buffer = [];
      await controlPlane.events(sid, batch).catch((e) => console.error("event flush failed", e));
    };
    const timer = setInterval(flush, 3000);
    session.on(voice.AgentSessionEventTypes.ConversationItemAdded, (ev) => {
      const item = ev.item;
      const text = item.textContent;
      if (text && (item.role === "user" || item.role === "assistant")) buffer.push({ type: "turn", role: item.role, content: text });
    });

    ctx.addShutdownCallback(async () => {
      clearInterval(timer);
      buffer.push({ type: "end", reason: "room_closed" });
      await flush();
    });

    await session.start({ agent, room: ctx.room });
    await session.generateReply({ instructions: s.bundle.prompt.greeting });
  },
});

cli.runApp(new WorkerOptions({ agent: fileURLToPath(import.meta.url), agentName: "aviroh-runtime" }));
