// Signed client for the aviroh control plane (/api/public/runtime/*).
import { createHmac } from "node:crypto";

const BASE = process.env.AVIROH_CONTROL_PLANE_URL!; // e.g. https://app.example.com
const SECRET = process.env.RUNTIME_SHARED_SECRET!;

async function call<T>(path: string, body: unknown): Promise<T> {
  const raw = JSON.stringify(body);
  const ts = Math.floor(Date.now() / 1000).toString();
  const sig = createHmac("sha256", SECRET).update(`${ts}.${raw}`).digest("hex");
  const res = await fetch(`${BASE}/api/public/runtime/${path}`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-aviroh-timestamp": ts, "x-aviroh-signature": sig },
    body: raw,
  });
  const json = (await res.json()) as T & { error?: string };
  if (!res.ok) throw new Error(json.error ?? `control plane ${path} ${res.status}`);
  return json;
}

export type ModelRef = { provider: string; model: string };
export type Bundle = {
  schema: "aviroh.bundle/v1";
  prompt: { persona: string; instructions: string; greeting: string; language: string; guardrails: string; handoff: string };
  runtime:
    | { mode: "native"; realtime: ModelRef; voice: string }
    | { mode: "composable"; stt: ModelRef; llm: ModelRef; tts: ModelRef & { voice: string } };
  knowledge: { knowledge_base_ids: string[]; top_k: number };
  tools: { id: string; name: string; description: string; parameters: Record<string, unknown>; timeout_ms: number }[];
};

export type OpenSession = { session_id: string; checksum: string; bundle: Bundle; credentials: Record<string, string> };

export const controlPlane = {
  openSession: (b: { session_id?: string; phone_number_id?: string; caller?: string; session_ref?: string }) => call<OpenSession>("session", b),
  retrieve: (session_id: string, query: string) => call<{ results: { content: string; score: number }[] }>("retrieve", { session_id, query }),
  tool: (session_id: string, tool: string, args: unknown) => call<{ ok: boolean; status: number; body: string }>("tool", { session_id, tool, args }),
  events: (session_id: string, events: unknown[]) => call<{ ok: true }>("events", { session_id, events }),
};
