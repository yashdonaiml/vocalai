// Execution engines. The only file that maps aviroh provider refs onto LiveKit plugins.
import * as openai from "@livekit/agents-plugin-openai";
import * as google from "@livekit/agents-plugin-google";
import * as deepgram from "@livekit/agents-plugin-deepgram";
import * as elevenlabs from "@livekit/agents-plugin-elevenlabs";
import * as cartesia from "@livekit/agents-plugin-cartesia";
import * as silero from "@livekit/agents-plugin-silero";
import type { Bundle, ModelRef } from "./control-plane.js";

type Creds = Record<string, string>;
const key = (c: Creds, p: string) => {
  if (!c[p]) throw new Error(`missing credential for ${p}`);
  return c[p];
};

function realtime(ref: ModelRef, voice: string, c: Creds) {
  switch (ref.provider) {
    case "openai":
      return new openai.realtime.RealtimeModel({ model: ref.model, voice, apiKey: key(c, "openai") });
    case "google":
      return new google.beta.realtime.RealtimeModel({ model: ref.model, voice, apiKey: key(c, "google") });
    default:
      throw new Error(`no realtime adapter for ${ref.provider}`);
  }
}

function stt(ref: ModelRef, c: Creds) {
  switch (ref.provider) {
    case "deepgram": return new deepgram.STT({ model: ref.model as never, apiKey: key(c, "deepgram") });
    case "openai": return new openai.STT({ model: ref.model, apiKey: key(c, "openai") });
    default: throw new Error(`no STT adapter for ${ref.provider}`);
  }
}

function llm(ref: ModelRef, c: Creds) {
  switch (ref.provider) {
    case "openai": return new openai.LLM({ model: ref.model, apiKey: key(c, "openai") });
    case "google": return new google.LLM({ model: ref.model, apiKey: key(c, "google") });
    // Anthropic via its OpenAI-compatible endpoint keeps one adapter shape.
    case "anthropic": return new openai.LLM({ model: ref.model, apiKey: key(c, "anthropic"), baseURL: "https://api.anthropic.com/v1/" });
    default: throw new Error(`no LLM adapter for ${ref.provider}`);
  }
}

function tts(ref: ModelRef & { voice: string }, c: Creds) {
  switch (ref.provider) {
    case "elevenlabs": return new elevenlabs.TTS({ model: ref.model, voiceId: ref.voice || undefined, apiKey: key(c, "elevenlabs") } as never);
    case "cartesia": return new cartesia.TTS({ model: ref.model, voice: ref.voice || undefined, apiKey: key(c, "cartesia") } as never);
    case "deepgram": return new deepgram.TTS({ model: ref.voice || ref.model, apiKey: key(c, "deepgram") } as never);
    case "openai": return new openai.TTS({ model: ref.model, voice: (ref.voice || "alloy") as never, apiKey: key(c, "openai") });
    default: throw new Error(`no TTS adapter for ${ref.provider}`);
  }
}

export async function buildSessionOptions(bundle: Bundle, creds: Creds) {
  const r = bundle.runtime;
  if (r.mode === "native") return { llm: realtime(r.realtime, r.voice, creds) };
  return { vad: await silero.VAD.load(), stt: stt(r.stt, creds), llm: llm(r.llm, creds), tts: tts(r.tts, creds) };
}
