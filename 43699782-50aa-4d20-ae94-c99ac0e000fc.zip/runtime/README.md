# aviroh Runtime Service

The Stealth Conversation Runtime. A LiveKit Agents worker that runs aviroh **runtime bundles**. It is deployed separately from the console, because media and SIP can't run on the edge.

```text
LiveKit dispatch (agentName "aviroh-runtime")
  → POST /api/public/runtime/session   bundle + provider credentials
  → engine: native realtime | composable STT→LLM→TTS
  → tools: search_knowledge → /retrieve, registry tools → /tool
  → transcripts/usage → /events, "end" on shutdown
```

All control-plane calls are HMAC-signed: `x-aviroh-signature = hex(HMAC_SHA256(RUNTIME_SHARED_SECRET, ts + "." + body))`.

## Env
| Var | Purpose |
| --- | --- |
| `LIVEKIT_URL`, `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET` | Same LiveKit project as the console |
| `AVIROH_CONTROL_PLANE_URL` | Console origin, e.g. `https://aviroh.example.com` |
| `RUNTIME_SHARED_SECRET` | Must equal the console's secret |

Provider keys are **not** set here. They come per session from the control plane (workspace BYOK first, then platform keys).

## Run
```bash
npm install
npm run dev          # local, connects to LiveKit
docker build -t aviroh-runtime . && docker run --env-file .env aviroh-runtime
```
Scale horizontally. LiveKit load-balances jobs across workers.

## Telephony
The console's Deployments tab creates a LiveKit SIP inbound trunk and dispatch rule per number. Point your Twilio/Telnyx Elastic SIP trunk at your LiveKit SIP URI.
